import AuthLayout from './Layouts/AuthLayout';
import logo from './logo.svg';
import './Scss/main.scss'

function App() {
  return (
    <div className="App">
      <AuthLayout/>
    </div>
  );
}

export default App;
