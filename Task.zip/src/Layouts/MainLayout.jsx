import React from 'react'

const MainLayout = () => {
  return (
    <div>MainLayout</div>
  )
}

export default MainLayout