import React from "react";

const LoginForm = () => {
  return (
    <form className="login__form p-med h100">
      <h2 className="login__header">Login as User</h2>
      <input className="login__input mt-small t-pad-small" />
      <input className="login__input mt-small t-pad-small" />
      <div>
        
      </div>
      <div className="login__buttonsContainer mt-med">
        <button className="login__button login--register">Register</button>
        <button className="login__button login--login">Login</button>
      </div>
    </form>
  );
};

export default LoginForm;
